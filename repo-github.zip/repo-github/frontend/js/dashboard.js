/**
 * dashboard.js
 * ---------------------------------------------------------------------------
 * Faz polling do endpoint `presencas` a cada N segundos e renderiza a lista
 * ao vivo, destacando os registros novos desde a última atualização.
 * ---------------------------------------------------------------------------
 */

(() => {
  const els = {
    statTotal: document.getElementById('statTotal'),
    statUltima: document.getElementById('statUltima'),
    listBody: document.getElementById('listBody'),
    liveStatus: document.getElementById('liveStatus'),
    btnConfig: document.getElementById('btnConfig'),
    modalBackdrop: document.getElementById('modalBackdrop'),
    cfgUrl: document.getElementById('cfgUrl'),
    cfgKey: document.getElementById('cfgKey'),
    cfgSave: document.getElementById('cfgSave'),
    cfgCancel: document.getElementById('cfgCancel')
  };

  let codigosConhecidos = new Set();
  let primeiraCarga = true;
  let timerId = null;

  function configuracaoValida() {
    return window.CONFIG.API_URL && !window.CONFIG.API_URL.startsWith('COLOQUE_AQUI')
        && window.CONFIG.API_KEY && !window.CONFIG.API_KEY.startsWith('COLOQUE_AQUI');
  }

  els.btnConfig.addEventListener('click', () => {
    els.cfgUrl.value = window.CONFIG.API_URL.startsWith('COLOQUE_AQUI') ? '' : window.CONFIG.API_URL;
    els.cfgKey.value = window.CONFIG.API_KEY.startsWith('COLOQUE_AQUI') ? '' : window.CONFIG.API_KEY;
    els.modalBackdrop.classList.add('show');
  });
  els.cfgCancel.addEventListener('click', () => els.modalBackdrop.classList.remove('show'));
  els.cfgSave.addEventListener('click', () => {
    window.CONFIG.API_URL = els.cfgUrl.value.trim();
    window.CONFIG.API_KEY = els.cfgKey.value.trim();
    els.modalBackdrop.classList.remove('show');
    primeiraCarga = true;
    codigosConhecidos = new Set();
    atualizar();
  });

  function renderLista(presencas) {
    if (!presencas.length) {
      els.listBody.innerHTML = `<div class="empty-state"><p>nenhuma presença registrada ainda</p></div>`;
      return;
    }

    els.listBody.innerHTML = presencas.map(p => {
      const ehNovo = !primeiraCarga && !codigosConhecidos.has(p.codigo + p.hora);
      return `
        <div class="row ${ehNovo ? 'novo' : ''}">
          <span class="cell-codigo">${escapeHtml(p.codigo)}</span>
          <span class="cell-nome">${escapeHtml(p.nome)}</span>
          <span class="cell-turma">${escapeHtml(p.turma || '—')}</span>
          <span class="cell-hora">${escapeHtml(p.hora || '—')}</span>
        </div>`;
    }).join('');

    codigosConhecidos = new Set(presencas.map(p => p.codigo + p.hora));
    primeiraCarga = false;
  }

  function escapeHtml(str) {
    const d = document.createElement('div');
    d.textContent = str == null ? '' : String(str);
    return d.innerHTML;
  }

  async function atualizar() {
    if (!configuracaoValida()) {
      els.liveStatus.textContent = 'configuração pendente';
      els.listBody.innerHTML = `<div class="empty-state"><p>defina a URL e a API Key acima para começar</p></div>`;
      return;
    }

    try {
      const res = await PresencaAPI.obterUltimasPresencas(window.CONFIG.LIMITE_ITENS);
      if (res.status !== 'ok') throw new Error(res.mensagem || 'erro desconhecido');

      els.statTotal.textContent = res.total;
      els.statUltima.textContent = res.presencas[0] ? res.presencas[0].hora : '—';
      renderLista(res.presencas);
      els.liveStatus.textContent = `atualizado às ${new Date().toLocaleTimeString('pt-BR')}`;
    } catch (err) {
      els.liveStatus.textContent = 'falha ao atualizar — tentando de novo';
    }
  }

  function iniciarPolling() {
    atualizar();
    timerId = window.setInterval(atualizar, window.CONFIG.POLL_INTERVAL_MS || 4000);
  }

  // Pausa o polling quando a aba está em segundo plano (economiza cotas
  // de execução do Apps Script) e retoma ao voltar o foco.
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      window.clearInterval(timerId);
    } else {
      iniciarPolling();
    }
  });

  iniciarPolling();
})();
