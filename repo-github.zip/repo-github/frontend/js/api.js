/**
 * api.js
 * ---------------------------------------------------------------------------
 * Camada única de comunicação com o backend (Apps Script Web App).
 * Usada tanto pelo leitor (index.html) quanto pelo dashboard (dashboard.html).
 *
 * Observação técnica: o Content-Type é forçado para 'text/plain' no POST.
 * Isso é proposital — Web Apps do Apps Script não respondem corretamente a
 * preflight (OPTIONS) de CORS, então evitamos que o navegador dispare um
 * preflight, mandando um Content-Type "simples". O Apps Script ainda
 * consegue ler o corpo como JSON normalmente (`e.postData.contents`).
 * ---------------------------------------------------------------------------
 */

const PresencaAPI = (() => {

  function getConfig() {
    if (!window.CONFIG || !window.CONFIG.API_URL || window.CONFIG.API_URL.startsWith('COLOQUE_AQUI')) {
      throw new Error('CONFIG_AUSENTE');
    }
    return window.CONFIG;
  }

  /**
   * Registra uma presença a partir de um código lido.
   * @param {string} codigo
   * @param {string} origem  identifica a origem da leitura (ex: 'camera', 'manual')
   * @returns {Promise<object>} resposta padronizada da API
   */
  async function registrarPresenca(codigo, origem) {
    const cfg = getConfig();

    const resposta = await fetch(cfg.API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({
        codigo: codigo,
        apiKey: cfg.API_KEY,
        origem: origem || 'app-web'
      })
    });

    if (!resposta.ok) {
      throw new Error('HTTP_' + resposta.status);
    }

    return await resposta.json();
  }

  /**
   * Busca as últimas presenças registradas (para o dashboard).
   * @param {number} limite
   */
  async function obterUltimasPresencas(limite) {
    const cfg = getConfig();
    const url = `${cfg.API_URL}?action=presencas&apiKey=${encodeURIComponent(cfg.API_KEY)}&limite=${limite || 20}`;

    const resposta = await fetch(url, { method: 'GET' });
    if (!resposta.ok) {
      throw new Error('HTTP_' + resposta.status);
    }
    return await resposta.json();
  }

  async function ping() {
    const cfg = getConfig();
    const resposta = await fetch(`${cfg.API_URL}?action=ping`, { method: 'GET' });
    return resposta.ok;
  }

  return { registrarPresenca, obterUltimasPresencas, ping, getConfig };
})();
