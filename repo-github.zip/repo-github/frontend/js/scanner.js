/**
 * scanner.js
 * ---------------------------------------------------------------------------
 * Controla a câmera (via html5-qrcode), o feedback visual de resultado e
 * a entrada manual de fallback.
 * ---------------------------------------------------------------------------
 */

(() => {
  const els = {
    reader: document.getElementById('reader'),
    scanHint: document.getElementById('scanHint'),
    statusDot: document.getElementById('statusDot'),
    statusText: document.getElementById('statusText'),
    resultOverlay: document.getElementById('resultOverlay'),
    resultIcon: document.getElementById('resultIcon'),
    resultName: document.getElementById('resultName'),
    resultMeta: document.getElementById('resultMeta'),
    resultMsg: document.getElementById('resultMsg'),
    manualCode: document.getElementById('manualCode'),
    manualSubmit: document.getElementById('manualSubmit'),
    btnConfig: document.getElementById('btnConfig'),
    modalBackdrop: document.getElementById('modalBackdrop'),
    cfgUrl: document.getElementById('cfgUrl'),
    cfgKey: document.getElementById('cfgKey'),
    cfgSave: document.getElementById('cfgSave'),
    cfgCancel: document.getElementById('cfgCancel')
  };

  let html5QrCode = null;
  let processando = false;          // trava para não processar duas leituras ao mesmo tempo
  let ultimoCodigo = null;
  let ultimoTimestamp = 0;

  /* -------------------------------------------------------------------- *
   *  Configuração em runtime (não usa localStorage — ver nota no README) *
   * -------------------------------------------------------------------- */
  function configuracaoValida() {
    return window.CONFIG.API_URL && !window.CONFIG.API_URL.startsWith('COLOQUE_AQUI')
        && window.CONFIG.API_KEY && !window.CONFIG.API_KEY.startsWith('COLOQUE_AQUI');
  }

  function abrirModalConfig() {
    els.cfgUrl.value = window.CONFIG.API_URL.startsWith('COLOQUE_AQUI') ? '' : window.CONFIG.API_URL;
    els.cfgKey.value = window.CONFIG.API_KEY.startsWith('COLOQUE_AQUI') ? '' : window.CONFIG.API_KEY;
    els.modalBackdrop.classList.add('show');
  }
  function fecharModalConfig() {
    els.modalBackdrop.classList.remove('show');
  }

  els.btnConfig.addEventListener('click', abrirModalConfig);
  els.cfgCancel.addEventListener('click', fecharModalConfig);
  els.cfgSave.addEventListener('click', () => {
    window.CONFIG.API_URL = els.cfgUrl.value.trim();
    window.CONFIG.API_KEY = els.cfgKey.value.trim();
    fecharModalConfig();
    atualizarStatusOcioso();
  });

  /* -------------------------------------------------------------------- *
   *  Feedback visual                                                     *
   * -------------------------------------------------------------------- */
  const ICONS = { sucesso: '✓', duplicado: '⏱', nao_encontrado: '✕', erro: '!' };

  function mostrarResultado(tipo, { nome, turma, hora, mensagem }) {
    const classe = tipo === 'sucesso' ? 'success' : (tipo === 'duplicado' ? 'warn' : 'error');

    els.resultOverlay.className = 'result-overlay show ' + classe;
    els.resultIcon.textContent = ICONS[tipo] || '!';
    els.resultName.textContent = nome || (tipo === 'nao_encontrado' ? 'Código não encontrado' : 'Erro');
    els.resultMeta.textContent = [turma, hora].filter(Boolean).join(' · ');
    els.resultMsg.textContent = mensagem || '';

    if (navigator.vibrate) {
      navigator.vibrate(tipo === 'sucesso' ? 80 : [60, 40, 60]);
    }

    window.setTimeout(() => {
      els.resultOverlay.classList.remove('show');
    }, window.CONFIG.TEMPO_EXIBICAO_RESULTADO_MS || 2500);
  }

  function atualizarStatusOcioso() {
    if (!configuracaoValida()) {
      els.statusText.textContent = 'configuração pendente — toque em ⚙';
      els.statusDot.style.background = '#C6394A';
    } else {
      els.statusText.textContent = 'câmera ativa · aguardando leitura';
      els.statusDot.style.background = '#0F9D71';
    }
  }

  /* -------------------------------------------------------------------- *
   *  Processamento de um código (vindo da câmera ou do campo manual)     *
   * -------------------------------------------------------------------- */
  async function processarCodigo(codigo, origem) {
    codigo = (codigo || '').trim();
    if (!codigo) return;

    if (!configuracaoValida()) {
      mostrarResultado('erro', { mensagem: 'Configure a URL e a API Key primeiro (ícone ⚙).' });
      return;
    }

    // Debounce no cliente: evita chamadas repetidas enquanto a câmera
    // continua enxergando o mesmo QR parado na frente da lente.
    const agora = Date.now();
    if (processando) return;
    if (codigo === ultimoCodigo && (agora - ultimoTimestamp) < window.CONFIG.DEBOUNCE_CLIENTE_MS) {
      return;
    }

    processando = true;
    ultimoCodigo = codigo;
    ultimoTimestamp = agora;
    els.statusText.textContent = 'verificando código…';

    try {
      const res = await PresencaAPI.registrarPresenca(codigo, origem);
      mostrarResultado(res.status, res);
    } catch (err) {
      mostrarResultado('erro', {
        mensagem: err.message === 'CONFIG_AUSENTE'
          ? 'Configure a URL e a API Key primeiro (ícone ⚙).'
          : 'Falha de conexão. Verifique sua internet e tente novamente.'
      });
    } finally {
      processando = false;
      atualizarStatusOcioso();
    }
  }

  /* -------------------------------------------------------------------- *
   *  Entrada manual (fallback)                                           *
   * -------------------------------------------------------------------- */
  els.manualSubmit.addEventListener('click', () => {
    const codigo = els.manualCode.value.trim().toUpperCase();
    if (!codigo) return;
    els.manualCode.value = '';
    processarCodigo(codigo, 'manual');
  });
  els.manualCode.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') els.manualSubmit.click();
  });

  /* -------------------------------------------------------------------- *
   *  Inicialização da câmera                                             *
   * -------------------------------------------------------------------- */
  async function iniciarCamera() {
    html5QrCode = new Html5Qrcode('reader', /* verbose= */ false);

    const config = {
      fps: 10,
      qrbox: { width: 220, height: 220 },
      aspectRatio: 1.0
    };

    try {
      await html5QrCode.start(
        { facingMode: 'environment' },
        config,
        (decodedText) => processarCodigo(decodedText, 'camera'),
        () => { /* erro de decodificação por frame: ignorado silenciosamente, é normal */ }
      );
      els.scanHint.textContent = 'posicione o qr code no quadro';
    } catch (err) {
      els.scanHint.textContent = 'câmera indisponível — use a leitura manual abaixo';
      els.statusText.textContent = 'sem acesso à câmera';
      els.statusDot.style.background = '#C6394A';
    }
  }

  atualizarStatusOcioso();
  iniciarCamera();
})();
