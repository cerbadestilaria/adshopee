/**
 * Config.gs
 * ---------------------------------------------------------------------------
 * Configurações centrais do sistema. Alterar valores aqui reflete em todo
 * o backend — evita "números mágicos" espalhados pelo código.
 * ---------------------------------------------------------------------------
 */

// Nomes das abas
const SHEET_CADASTRO = 'Cadastro';
const SHEET_LOGS = 'Logs';

// Índices de coluna da aba Cadastro (1-based, igual ao Apps Script/Sheets)
const COL_CODIGO = 1;
const COL_NOME = 2;
const COL_TURMA = 3;
const COL_PRESENCA = 4;
const COL_DATA = 5;
const COL_HORA = 6;
const COL_ULTIMA_ATUALIZACAO = 7;

// Janela anti-duplicidade: nº de segundos em que uma nova leitura do MESMO
// código é considerada duplicata e não gera novo registro.
const JANELA_DUPLICIDADE_SEGUNDOS = 15;

// Tempo (em segundos) que o índice código->linha fica em cache antes de
// ser reconstruído a partir da planilha.
const CACHE_INDICE_SEGUNDOS = 300; // 5 minutos

// Timezone usado para formatar data/hora nos registros
const TIMEZONE = 'America/Sao_Paulo';

/** Recupera a API key configurada nas Script Properties. */
function getApiKey_() {
  return PropertiesService.getScriptProperties().getProperty('API_KEY');
}
