/**
 * Code.gs
 * ---------------------------------------------------------------------------
 * Ponto de entrada da Web App (Apps Script).
 *
 * Endpoints (todos via HTTP, deploy como "Web App"):
 *
 *   POST  ?  body: { "codigo": "ALU-0001", "apiKey": "..." }
 *     -> registra presença. Resposta JSON:
 *        { status: 'sucesso' | 'duplicado' | 'nao_encontrado' | 'erro',
 *          nome, turma, hora, mensagem }
 *
 *   GET   ?action=presencas&apiKey=...&limite=20
 *     -> retorna as últimas presenças registradas, para o dashboard.
 *
 *   GET   ?action=ping
 *     -> healthcheck simples, não exige apiKey.
 * ---------------------------------------------------------------------------
 */

function doGet(e) {
  const action = e.parameter.action;

  if (action === 'ping') {
    return jsonResponse_({ status: 'ok', timestamp: new Date().toISOString() });
  }

  if (action === 'presencas') {
    if (!validarApiKey_(e.parameter.apiKey)) {
      return jsonResponse_({ status: 'erro', mensagem: 'API key inválida.' });
    }
    const limite = parseInt(e.parameter.limite, 10) || 20;
    return jsonResponse_(obterUltimasPresencas_(limite));
  }

  return jsonResponse_({ status: 'erro', mensagem: 'Ação desconhecida.' });
}

function doPost(e) {
  let payload;
  try {
    payload = JSON.parse(e.postData.contents);
  } catch (err) {
    registrarLog_('(inválido)', 'erro', 'JSON malformado: ' + err.message, 'doPost');
    return jsonResponse_({ status: 'erro', mensagem: 'Requisição inválida.' });
  }

  const codigo = (payload.codigo || '').toString().trim();
  const origem = payload.origem || 'app-web';

  if (!validarApiKey_(payload.apiKey)) {
    registrarLog_(codigo, 'erro', 'API key inválida', origem);
    return jsonResponse_({ status: 'erro', mensagem: 'Não autorizado.' });
  }

  if (!codigo) {
    registrarLog_(codigo, 'erro', 'Código vazio na requisição', origem);
    return jsonResponse_({ status: 'erro', mensagem: 'Código não informado.' });
  }

  return registrarPresenca_(codigo, origem);
}

/**
 * Núcleo do sistema: localiza a pessoa, valida duplicidade e grava presença.
 * Usa LockService para serializar escritas concorrentes e evitar
 * condições de corrida (duas leituras simultâneas do mesmo código).
 */
function registrarPresenca_(codigo, origem) {
  const lock = LockService.getScriptLock();
  const conseguiuLock = lock.tryLock(10000); // espera até 10s pela vez

  if (!conseguiuLock) {
    registrarLog_(codigo, 'erro', 'Timeout aguardando lock (sistema sob alta concorrência)', origem);
    return jsonResponse_({
      status: 'erro',
      mensagem: 'Sistema ocupado, tente novamente em instantes.'
    });
  }

  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const cadastro = ss.getSheetByName(SHEET_CADASTRO);

    const linha = localizarLinhaPorCodigo_(cadastro, codigo);

    if (linha === -1) {
      registrarLog_(codigo, 'nao_encontrado', 'Código não existe no cadastro', origem);
      return jsonResponse_({
        status: 'nao_encontrado',
        mensagem: 'Código não encontrado. Verifique o QR Code.'
      });
    }

    const valores = cadastro.getRange(linha, 1, 1, 7).getValues()[0];
    const nome = valores[COL_NOME - 1];
    const turma = valores[COL_TURMA - 1];
    const presencaAtual = valores[COL_PRESENCA - 1];
    const ultimaAtualizacao = valores[COL_ULTIMA_ATUALIZACAO - 1];

    // --- Verificação anti-duplicidade -----------------------------------
    if (presencaAtual === 'Sim' && ultimaAtualizacao) {
      const segundosDesdeUltima = (new Date().getTime() - new Date(ultimaAtualizacao).getTime()) / 1000;
      if (segundosDesdeUltima < JANELA_DUPLICIDADE_SEGUNDOS) {
        registrarLog_(codigo, 'duplicado', `Nova leitura ${Math.round(segundosDesdeUltima)}s após a anterior`, origem);
        return jsonResponse_({
          status: 'duplicado',
          nome: nome,
          turma: turma,
          mensagem: 'Presença já registrada para ' + nome + '.'
        });
      }
      // Fora da janela: permite re-registro (ex: reentrada em outro turno),
      // atualizando data/hora normalmente.
    }

    // --- Grava presença ----------------------------------------------------
    const agora = new Date();
    const dataFormatada = Utilities.formatDate(agora, TIMEZONE, 'dd/MM/yyyy');
    const horaFormatada = Utilities.formatDate(agora, TIMEZONE, 'HH:mm:ss');

    cadastro.getRange(linha, COL_PRESENCA).setValue('Sim');
    cadastro.getRange(linha, COL_DATA).setValue(dataFormatada);
    cadastro.getRange(linha, COL_HORA).setValue(horaFormatada);
    cadastro.getRange(linha, COL_ULTIMA_ATUALIZACAO).setValue(agora);

    // Invalida o cache do índice pois não é necessário (linha não mudou),
    // mas garante que o cache de "última leitura" fique consistente.
    invalidarCachePresenca_(codigo);

    registrarLog_(codigo, 'sucesso', `Presença registrada para ${nome} (${turma})`, origem);

    return jsonResponse_({
      status: 'sucesso',
      nome: nome,
      turma: turma,
      hora: horaFormatada,
      mensagem: 'Presença confirmada para ' + nome + '.'
    });
  } catch (err) {
    registrarLog_(codigo, 'erro', 'Exceção: ' + err.message, origem);
    return jsonResponse_({
      status: 'erro',
      mensagem: 'Erro interno ao registrar presença.'
    });
  } finally {
    lock.releaseLock();
  }
}

/**
 * Localiza a linha (1-based) de um código na aba Cadastro.
 * Usa um índice em cache (CacheService) para evitar varrer a planilha
 * inteira a cada leitura — importante para performance com muitas linhas.
 */
function localizarLinhaPorCodigo_(cadastro, codigo) {
  const cache = CacheService.getScriptCache();
  const cacheKey = 'indice_codigo_' + codigo;
  const cacheado = cache.get(cacheKey);

  if (cacheado !== null) {
    const linha = parseInt(cacheado, 10);
    // Confirma que a linha ainda corresponde ao código certo (planilha pode
    // ter sido editada manualmente por um humano nesse meio-tempo).
    const valorAtual = cadastro.getRange(linha, COL_CODIGO).getValue();
    if (valorAtual === codigo) {
      return linha;
    }
  }

  // Cache miss ou inválido: busca linear (uma vez) e recacheia.
  const dados = cadastro.getDataRange().getValues();
  for (let i = 1; i < dados.length; i++) { // pula cabeçalho
    if (dados[i][COL_CODIGO - 1] === codigo) {
      const linhaReal = i + 1;
      cache.put(cacheKey, String(linhaReal), CACHE_INDICE_SEGUNDOS);
      return linhaReal;
    }
  }

  return -1;
}

function invalidarCachePresenca_(codigo) {
  // Mantido como ponto de extensão caso o cache de dados de presença
  // (não apenas o índice de linha) passe a ser usado no futuro.
}

/** Retorna as N presenças mais recentes, para o dashboard ao vivo. */
function obterUltimasPresencas_(limite) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const cadastro = ss.getSheetByName(SHEET_CADASTRO);
  const dados = cadastro.getDataRange().getValues();

  const presentes = [];
  for (let i = 1; i < dados.length; i++) {
    const linha = dados[i];
    if (linha[COL_PRESENCA - 1] === 'Sim') {
      presentes.push({
        codigo: linha[COL_CODIGO - 1],
        nome: linha[COL_NOME - 1],
        turma: linha[COL_TURMA - 1],
        data: linha[COL_DATA - 1],
        hora: linha[COL_HORA - 1],
        ultimaAtualizacao: linha[COL_ULTIMA_ATUALIZACAO - 1]
      });
    }
  }

  presentes.sort((a, b) => new Date(b.ultimaAtualizacao) - new Date(a.ultimaAtualizacao));

  return {
    status: 'ok',
    total: presentes.length,
    presencas: presentes.slice(0, limite)
  };
}

function validarApiKey_(chaveRecebida) {
  const chaveEsperada = getApiKey_();
  return !!chaveEsperada && chaveRecebida === chaveEsperada;
}

function jsonResponse_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
