/**
 * SheetSetup.gs
 * ---------------------------------------------------------------------------
 * Responsável por criar/garantir a estrutura correta da planilha.
 * Rode a função `setupPlanilha()` UMA VEZ, manualmente, pelo editor do
 * Apps Script (menu "Executar" > selecionar "setupPlanilha").
 *
 * Cria duas abas:
 *   - "Cadastro": dados das pessoas + status de presença
 *   - "Logs":     auditoria de todas as tentativas de check-in
 * ---------------------------------------------------------------------------
 */

/** Cabeçalhos oficiais da aba de cadastro. Não altere a ordem — o backend
 *  depende dos índices de coluna definidos em Config.gs. */
const CADASTRO_HEADERS = [
  'Código',
  'Nome',
  'Turma',
  'Presença',
  'Data',
  'Hora',
  'Última Atualização'
];

const LOGS_HEADERS = [
  'Timestamp',
  'Código',
  'Resultado',
  'Detalhes',
  'Origem'
];

function setupPlanilha() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // --- Aba Cadastro -----------------------------------------------------
  let cadastro = ss.getSheetByName(SHEET_CADASTRO);
  if (!cadastro) {
    cadastro = ss.insertSheet(SHEET_CADASTRO);
  }
  if (cadastro.getLastRow() === 0) {
    cadastro.appendRow(CADASTRO_HEADERS);
    cadastro.setFrozenRows(1);
    cadastro
      .getRange(1, 1, 1, CADASTRO_HEADERS.length)
      .setFontWeight('bold')
      .setBackground('#4a86e8')
      .setFontColor('#ffffff');
    cadastro.autoResizeColumns(1, CADASTRO_HEADERS.length);
  }

  // --- Aba Logs -----------------------------------------------------------
  let logs = ss.getSheetByName(SHEET_LOGS);
  if (!logs) {
    logs = ss.insertSheet(SHEET_LOGS);
  }
  if (logs.getLastRow() === 0) {
    logs.appendRow(LOGS_HEADERS);
    logs.setFrozenRows(1);
    logs
      .getRange(1, 1, 1, LOGS_HEADERS.length)
      .setFontWeight('bold')
      .setBackground('#6aa84f')
      .setFontColor('#ffffff');
    logs.autoResizeColumns(1, LOGS_HEADERS.length);
  }

  // --- Gera a API KEY na primeira execução, se ainda não existir ---------
  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty('API_KEY')) {
    const novaChave = Utilities.getUuid();
    props.setProperty('API_KEY', novaChave);
    Logger.log('API_KEY gerada: ' + novaChave);
    Logger.log('Guarde essa chave — o frontend precisa dela para chamar a API.');
  } else {
    Logger.log('API_KEY já existente: ' + props.getProperty('API_KEY'));
  }

  SpreadsheetApp.getUi().alert(
    'Planilha configurada com sucesso!\n\n' +
    'Confira o Log de execução (Ver > Registros de execução) para pegar sua API_KEY.'
  );
}

/**
 * Utilitário opcional: popula a planilha com pessoas de teste.
 * Rode manualmente apenas em ambiente de teste.
 */
function popularDadosTeste() {
  const cadastro = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_CADASTRO);
  const dadosTeste = [
    ['ALU-0001', 'Maria Silva', '3A', 'Não', '', '', ''],
    ['ALU-0002', 'João Souza', '3A', 'Não', '', '', ''],
    ['ALU-0003', 'Ana Pereira', '3B', 'Não', '', '', '']
  ];
  cadastro.getRange(cadastro.getLastRow() + 1, 1, dadosTeste.length, dadosTeste[0].length)
    .setValues(dadosTeste);
}
