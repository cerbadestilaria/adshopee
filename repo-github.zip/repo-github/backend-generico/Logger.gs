/**
 * Logger.gs
 * ---------------------------------------------------------------------------
 * Registra cada tentativa de check-in na aba "Logs", para auditoria e
 * depuração. Nunca lança erro para não derrubar o fluxo principal — logging
 * é "best effort".
 * ---------------------------------------------------------------------------
 */

/**
 * @param {string} codigo    Código lido no QR.
 * @param {string} resultado 'sucesso' | 'duplicado' | 'nao_encontrado' | 'erro'
 * @param {string} detalhes  Texto livre com contexto adicional.
 * @param {string} origem    Identificador de origem da chamada (ex: IP/user-agent, se disponível).
 */
function registrarLog_(codigo, resultado, detalhes, origem) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const logs = ss.getSheetByName(SHEET_LOGS);
    if (!logs) return; // se a aba não existe ainda, não trava o fluxo

    logs.appendRow([
      new Date(),
      codigo || '(vazio)',
      resultado,
      detalhes || '',
      origem || 'desconhecida'
    ]);
  } catch (err) {
    // Logging nunca deve quebrar a aplicação principal.
    Logger.log('Falha ao registrar log: ' + err.message);
  }
}
