# Etapa 2 — Frontend (Leitor de QR + Dashboard ao vivo)

## O que foi entregue

| Arquivo | Responsabilidade |
|---|---|
| `index.html` | Tela do leitor: câmera com mira animada, banner de resultado (sucesso/duplicado/erro), entrada manual de fallback. |
| `dashboard.html` | Painel ao vivo: contador de presenças, lista das leituras mais recentes, atualização automática. |
| `js/api.js` | Camada única de comunicação com a Web App (POST para registrar, GET para consultar) — compartilhada pelas duas telas. |
| `js/scanner.js` | Lógica da câmera (biblioteca `html5-qrcode`), debounce no cliente, feedback visual, modal de configuração. |
| `js/dashboard.js` | Polling a cada 4s, renderização da lista, destaque de itens novos, pausa quando a aba está em segundo plano. |

## Configuração antes de publicar

Em **ambos** os arquivos HTML existe um bloco `CONFIG` no topo:

```js
const CONFIG = {
  API_URL: 'COLOQUE_AQUI_A_URL_DA_WEB_APP',
  API_KEY: 'COLOQUE_AQUI_SUA_API_KEY',
  ...
};
```

Preencha com a URL de deploy e a `API_KEY` geradas na Etapa 1. Se preferir não editar o arquivo, também é possível configurar em tempo de execução clicando no ícone **⚙** (leitor) ou no link **"Definir URL e API Key"** (dashboard) — mas por padrão não persiste após fechar a aba (decisão proposital, ver nota abaixo).

> **Nota sobre persistência:** o modal de configuração guarda os valores só em memória, não em `localStorage`. Para uso real (produção), edite o `CONFIG` diretamente nos arquivos antes de publicar — assim a configuração já vem pronta em todo carregamento da página, sem depender do navegador de cada aparelho.

## Onde hospedar

Estes são arquivos estáticos (HTML/JS puro) — não precisam de servidor Node, só de um host HTTPS (câmera só funciona em contexto seguro). Opções gratuitas mais simples:

- **GitHub Pages**: suba a pasta `frontend/` para um repositório e ative Pages.
- **Firebase Hosting**: `firebase deploy` com a pasta `frontend/` como `public`.
- **Netlify/Vercel**: arraste a pasta no painel deles.

Qualquer uma funciona igual — são só arquivos estáticos consumindo a API do Apps Script.

## Como o fluxo funciona na prática

1. A página abre e pede permissão de câmera (`facingMode: 'environment'`, ou seja, câmera traseira).
2. A cada frame, a lib tenta decodificar um QR. Ao achar um código, chama `processarCodigo`.
3. **Debounce no cliente** (3s por padrão): se a câmera continuar "vendo" o mesmo QR parado, não dispara novas requisições — evita spam de rede e de UI piscando.
4. A requisição vai para o Apps Script, que aplica a regra definitiva de duplicidade (15s, no servidor — é a fonte da verdade, o cliente é só uma otimização de UX).
5. O banner assume a cor certa (verde/âmbar/vermelho), some sozinho após 2,5s, e a câmera volta a escanear.
6. Se a câmera falhar (permissão negada, dispositivo sem câmera), o campo de **entrada manual** sempre funciona como fallback — importante para não travar o evento por causa de um celular específico.
7. O **dashboard** consulta `?action=presencas` a cada 4s e re-renderiza a lista, destacando novidades — pausa o polling automaticamente se a aba for pra segundo plano, para não gastar cota de execução do Apps Script à toa.

## Testando localmente

Como é necessário HTTPS (ou `localhost`) para a câmera funcionar, para testar local:

```bash
cd frontend
python3 -m http.server 8000
# depois abra http://localhost:8000
```

## Próxima etapa

**Etapa 3:** Hardening final — checklist de segurança (rotação de API key, restrição de origem, rate limiting adicional), testes de carga simulando leituras simultâneas, e um guia único de deploy ponta a ponta (planilha → Apps Script → frontend) para você usar no primeiro evento real.

Quer que eu siga para a Etapa 3, ou prefere primeiro publicar e testar o leitor + dashboard com dados reais?
