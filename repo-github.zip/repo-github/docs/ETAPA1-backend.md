# Etapa 1 — Backend (Google Apps Script) + Planilha

## O que foi entregue nesta etapa

| Arquivo | Responsabilidade |
|---|---|
| `Config.gs` | Constantes centrais: nomes de abas, índices de coluna, janela anti-duplicidade (15s), timezone. |
| `SheetSetup.gs` | Cria as abas `Cadastro` e `Logs` com cabeçalhos corretos e gera a `API_KEY`. Rodar uma única vez. |
| `Logger.gs` | Grava cada tentativa de check-in (sucesso/duplicado/não encontrado/erro) na aba `Logs`. |
| `Code.gs` | API HTTP da Web App: `doPost` (registrar presença) e `doGet` (healthcheck + consulta para o dashboard). |

## Como implantar

1. Crie uma planilha nova no Google Sheets (ou use a existente com os dados de cadastro).
2. Menu **Extensões → Apps Script**.
3. Crie os 4 arquivos `.gs` acima (mesmo nome, mesmo conteúdo).
4. No editor, selecione a função `setupPlanilha` no menu de funções e clique em **Executar**.
   - Na primeira execução o Google vai pedir autorização — aceite.
   - Isso cria as abas `Cadastro`/`Logs` e gera a `API_KEY`.
5. Veja **Ver → Registros de execução** para copiar a `API_KEY` gerada. Guarde-a — o frontend vai precisar dela.
6. (Opcional, só para testar) rode `popularDadosTeste` para inserir 3 pessoas fake.
7. Menu **Implantar → Nova implantação**:
   - Tipo: **App da Web**
   - Executar como: **Eu**
   - Quem pode acessar: **Qualquer pessoa** (a segurança real fica por conta da `API_KEY`, verificada em toda chamada — sem ela, a API recusa a requisição)
8. Copie a **URL da Web App** gerada — é o endpoint que o frontend vai chamar.

## Como testar rapidamente (antes do frontend existir)

Healthcheck (não exige chave):
```
GET https://SEU_DEPLOY_URL/exec?action=ping
```

Consultar presenças (dashboard):
```
GET https://SEU_DEPLOY_URL/exec?action=presencas&apiKey=SUA_API_KEY&limite=20
```

Registrar presença (o que o leitor de QR vai chamar):
```bash
curl -X POST "https://SEU_DEPLOY_URL/exec" \
  -H "Content-Type: text/plain" \
  -d '{"codigo":"ALU-0001","apiKey":"SUA_API_KEY","origem":"teste-manual"}'
```
> Nota: Apps Script Web Apps exigem que o `Content-Type` do POST seja `text/plain`
> para evitar preflight CORS — o frontend (Etapa 2) já vai fazer isso certo.

## Decisões técnicas desta etapa (e por quê)

- **`LockService.getScriptLock()`**: garante que duas leituras do mesmo código não gravem simultaneamente — elimina a condição de corrida na raiz, não só via checagem de aplicação.
- **Janela de 15s contra duplicidade**: leitura acidental repetida (aproximar o celular duas vezes) não gera novo registro nem erro — apenas informa "já registrado".
- **Cache de índice (`CacheService`)**: evita varrer a planilha inteira a cada leitura; com o volume estimado (200–2.000/dia) isso mantém a resposta rápida mesmo com centenas/milhares de linhas de cadastro.
- **API_KEY obrigatória**: como a Web App precisa ser pública ("Qualquer pessoa"), a chave é a única barreira contra chamadas maliciosas diretas ao endpoint. Ela nunca aparece na URL do app (vai no corpo/parâmetro, não em link compartilhável).
- **Logs nunca derrubam o fluxo principal**: qualquer falha ao gravar log é capturada e ignorada silenciosamente (best-effort), para nunca impedir o check-in real por causa de um problema de auditoria.

## Próxima etapa

**Etapa 2:** Frontend — tela de leitura de QR Code (`index.html` + `scanner.js`) com feedback visual de sucesso/erro/duplicidade, e o dashboard ao vivo (`dashboard.html`) com polling a cada 4s.

Posso seguir para a Etapa 2?
