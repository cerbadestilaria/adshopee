# Etapa 3 — Adaptação para a planilha real (aba ABS) + roteiro de teste

## O que mudou em relação à Etapa 1

| Antes (genérico) | Agora (adaptado à ABS) |
|---|---|
| Aba própria "Cadastro" com 7 colunas criadas do zero | Reaproveita a aba **ABS** já existente — só lê `Código BPO` (coluna A) e `colaborador` (coluna B) |
| Presença/Data/Hora em 3 colunas fixas | **Uma única coluna nova**, `Check-in QR (Hora)`, criada automaticamente no fim da aba (idempotente — roda o setup quantas vezes quiser sem duplicar) |
| Duplicidade checada lendo a célula da planilha | Duplicidade checada via `CacheService` (mais rápido, e não depende de formato de célula) |
| Logs numa aba "Logs" dentro da mesma planilha | Logs numa **planilha separada**, criada automaticamente (`Logs — Sistema de Presença QR`) — a planilha ABS nunca ganha abas novas |

**Nenhuma coluna de frequência oficial (`P`, `F`, `DSR`, `AM`, `TR`...) é lida ou escrita por este sistema.**

## Onde testar

Você já tem a cópia de teste criada:
**https://docs.google.com/spreadsheets/d/1WJ0_5N6u5Qx5LM-ZAdk63ESbZflK0efTs2JLhRtDqvI/edit**

## Passo a passo

1. Abra a planilha de **teste** no link acima.
2. **Extensões → Apps Script**.
3. Apague o conteúdo padrão e crie os 4 arquivos com o conteúdo desta etapa: `Code.gs`, `Config.gs`, `SheetSetup.gs`, `Logger.gs`.
4. Selecione a função **`setupPlanilha`** no dropdown e clique em **Executar**. Autorize quando pedido.
5. Confira em **Ver → Registros de execução**:
   - A `API_KEY` gerada.
   - O link da nova planilha de **Logs** (foi criada separada, dá uma olhada nela).
6. Volte na aba **ABS** da planilha de teste — repare que só apareceu **uma coluna nova no final**, `Check-in QR (Hora)`. Nada mais mudou.
7. **Implantar → Nova implantação → App da Web** (Executar como: Eu / Acesso: Qualquer pessoa). Copie a URL gerada.

## Testando o check-in (antes de mexer no frontend)

Pegue um `Código BPO` real da planilha de teste (ex: `LD106417`) e rode:

```bash
curl -X POST "https://SEU_DEPLOY_URL/exec" \
  -H "Content-Type: text/plain" \
  -d '{"codigo":"LD106417","apiKey":"SUA_API_KEY","origem":"teste-curl"}'
```

Resultado esperado: `{"status":"sucesso","nome":"CAROLAINE NOGUEIRA DA SILVA", ...}`, e a célula `Check-in QR (Hora)` daquela linha preenchida.

Rode o **mesmo comando de novo, na sequência** — deve voltar `"status":"duplicado"` (janela de 15s). Espere 15s e rode de novo — deve voltar `"sucesso"` outra vez, atualizando o horário.

Teste também um código que não existe:
```bash
curl -X POST "https://SEU_DEPLOY_URL/exec" \
  -H "Content-Type: text/plain" \
  -d '{"codigo":"NAO-EXISTE","apiKey":"SUA_API_KEY","origem":"teste-curl"}'
```
Esperado: `{"status":"nao_encontrado", ...}`.

## Depois de validar

Só depois de rodar esses testes na cópia e confirmar que está tudo certo (sem duplicidade indevida, sem erro, coluna nova preenchendo certo) é que faz sentido repetir o mesmo setup na planilha **real**. Quando chegar nessa hora, me avise — o procedimento é idêntico, só troca a planilha de destino.

## Próximo passo sugerido

Configurar o `frontend/index.html` (Etapa 2) com a URL e API_KEY dessa implantação de teste, gerar um QR Code de verdade para o código `LD106417` e testar o fluxo completo com a câmera do celular.

Quer que eu gere um QR Code de teste pra você já usar?
