/**
 * SheetSetup.gs  (versão adaptada)
 * ---------------------------------------------------------------------------
 * Rode `setupPlanilha()` UMA VEZ pelo editor do Apps Script, com este
 * script vinculado à planilha de TESTE (ou, futuramente, à real, depois de
 * validado). Ele:
 *
 *   1. NÃO mexe em nenhuma coluna existente da aba ABS.
 *   2. Garante que exista a coluna "Check-in QR (Hora)" — cria só se não
 *      existir ainda (idempotente: pode rodar de novo sem duplicar nada).
 *   3. Cria uma planilha SEPARADA para logs (não entra na planilha ABS).
 *   4. Gera a API_KEY.
 * ---------------------------------------------------------------------------
 */

function setupPlanilha() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const abs = ss.getSheetByName(SHEET_ABS);

  if (!abs) {
    SpreadsheetApp.getUi().alert(
      'Aba "ABS" não encontrada nesta planilha. Confirme se este script está ' +
      'vinculado ao arquivo certo antes de continuar.'
    );
    return;
  }

  // --- 1. Garante a coluna de check-in, sem duplicar -----------------------
  const colCheckin = garantirColunaCheckin_(abs);
  Logger.log('Coluna de check-in pronta na posição: ' + colCheckin);

  // --- 2. Cria a planilha de logs separada, se ainda não existir -----------
  const props = PropertiesService.getScriptProperties();
  let logSpreadsheetId = props.getProperty('LOG_SPREADSHEET_ID');

  if (!logSpreadsheetId) {
    const novaPlanilhaLogs = SpreadsheetApp.create('Logs — Sistema de Presença QR');
    const abaLogs = novaPlanilhaLogs.getSheets()[0];
    abaLogs.setName('Logs');
    abaLogs.appendRow(['Timestamp', 'Código', 'Nome', 'Resultado', 'Detalhes', 'Origem']);
    abaLogs.setFrozenRows(1);
    abaLogs
      .getRange(1, 1, 1, 6)
      .setFontWeight('bold')
      .setBackground('#6aa84f')
      .setFontColor('#ffffff');

    logSpreadsheetId = novaPlanilhaLogs.getId();
    props.setProperty('LOG_SPREADSHEET_ID', logSpreadsheetId);
    Logger.log('Planilha de logs criada: ' + novaPlanilhaLogs.getUrl());
  } else {
    Logger.log('Planilha de logs já existente: ' +
      'https://docs.google.com/spreadsheets/d/' + logSpreadsheetId);
  }

  // --- 3. Gera a API_KEY, se ainda não existir ------------------------------
  if (!props.getProperty('API_KEY')) {
    const novaChave = Utilities.getUuid();
    props.setProperty('API_KEY', novaChave);
    Logger.log('API_KEY gerada: ' + novaChave);
  } else {
    Logger.log('API_KEY já existente: ' + props.getProperty('API_KEY'));
  }

  SpreadsheetApp.getUi().alert(
    'Setup concluído!\n\n' +
    'Veja "Ver > Registros de execução" para copiar a API_KEY e o link da ' +
    'planilha de logs. A aba ABS não teve nenhuma coluna existente alterada.'
  );
}

/**
 * Procura o cabeçalho CHECKIN_HEADER na linha 1 da aba ABS.
 * Se não existir, cria como a última coluna. Retorna o índice (1-based).
 * Idempotente — seguro rodar múltiplas vezes.
 */
function garantirColunaCheckin_(abs) {
  const ultimaColuna = abs.getLastColumn();
  const cabecalhos = abs.getRange(1, 1, 1, ultimaColuna).getValues()[0];

  for (let i = 0; i < cabecalhos.length; i++) {
    if (cabecalhos[i] === CHECKIN_HEADER) {
      return i + 1; // já existe, reaproveita
    }
  }

  // Não existe: cria como a próxima coluna, sem tocar nas anteriores.
  const novaColuna = ultimaColuna + 1;
  const celula = abs.getRange(1, novaColuna);
  celula.setValue(CHECKIN_HEADER);
  celula.setFontWeight('bold').setBackground('#4a86e8').setFontColor('#ffffff');
  return novaColuna;
}
