/**
 * Config.gs  (versão adaptada à planilha real "Controle de Absenteísmo")
 * ---------------------------------------------------------------------------
 * Esta versão foi ajustada à estrutura JÁ EXISTENTE da aba "ABS" — não
 * criamos abas novas nem alteramos colunas de frequência oficiais (P, F,
 * DSR, AM, TR...). O check-in por QR grava numa única coluna nova, criada
 * no final da aba, e os logs vão para uma planilha separada.
 * ---------------------------------------------------------------------------
 */

// Nome da aba onde estão os colaboradores (NÃO ALTERAR — é a aba oficial)
const SHEET_ABS = 'ABS';

// Colunas já existentes na aba ABS (1-based)
const COL_CODIGO = 1;   // "Código BPO" — identificador único, vai no QR Code
const COL_NOME = 2;     // "colaborador"
const COL_TURNO = 6;    // "Turno" (informativo, exibido na confirmação)

// Cabeçalho da coluna NOVA que este sistema cria e mantém.
// Se a coluna com esse nome já existir, ela é reaproveitada — nunca duplicada.
const CHECKIN_HEADER = 'Check-in QR (Hora)';

// Janela anti-duplicidade (segundos). Verificada via CacheService — não
// depende de ler/parsear a célula, então funciona mesmo que alguém formate
// a coluna manualmente depois.
const JANELA_DUPLICIDADE_SEGUNDOS = 15;

const CACHE_INDICE_SEGUNDOS = 300; // 5 minutos
const TIMEZONE = 'America/Sao_Paulo';

function getApiKey_() {
  return PropertiesService.getScriptProperties().getProperty('API_KEY');
}

function getLogSpreadsheetId_() {
  return PropertiesService.getScriptProperties().getProperty('LOG_SPREADSHEET_ID');
}
