/**
 * Code.gs  (versão adaptada à planilha real — aba ABS)
 * ---------------------------------------------------------------------------
 * Mesmo contrato de API da versão genérica (Etapa 1), mas:
 *   - lê/escreve na aba "ABS" existente, respeitando as colunas oficiais
 *   - duplicidade é checada via CacheService (não lê a célula)
 *   - grava apenas na coluna "Check-in QR (Hora)" (criada no setup)
 *   - logs vão para a planilha separada (Logger.gs)
 * ---------------------------------------------------------------------------
 */

function doGet(e) {
  const action = e.parameter.action;

  if (action === 'ping') {
    return jsonResponse_({ status: 'ok', timestamp: new Date().toISOString() });
  }

  if (action === 'presencas') {
    if (!validarApiKey_(e.parameter.apiKey)) {
      return jsonResponse_({ status: 'erro', mensagem: 'API key inválida.' });
    }
    const limite = parseInt(e.parameter.limite, 10) || 20;
    return jsonResponse_(obterUltimosCheckins_(limite));
  }

  return jsonResponse_({ status: 'erro', mensagem: 'Ação desconhecida.' });
}

function doPost(e) {
  let payload;
  try {
    payload = JSON.parse(e.postData.contents);
  } catch (err) {
    registrarLog_('(inválido)', '', 'erro', 'JSON malformado: ' + err.message, 'doPost');
    return jsonResponse_({ status: 'erro', mensagem: 'Requisição inválida.' });
  }

  const codigo = (payload.codigo || '').toString().trim();
  const origem = payload.origem || 'app-web';

  if (!validarApiKey_(payload.apiKey)) {
    registrarLog_(codigo, '', 'erro', 'API key inválida', origem);
    return jsonResponse_({ status: 'erro', mensagem: 'Não autorizado.' });
  }

  if (!codigo) {
    registrarLog_(codigo, '', 'erro', 'Código vazio na requisição', origem);
    return jsonResponse_({ status: 'erro', mensagem: 'Código não informado.' });
  }

  return registrarCheckin_(codigo, origem);
}

/**
 * Núcleo: localiza o colaborador pelo "Código BPO", valida duplicidade via
 * cache, e grava o horário na coluna "Check-in QR (Hora)". Usa LockService
 * para serializar escritas e evitar condição de corrida.
 */
function registrarCheckin_(codigo, origem) {
  const lock = LockService.getScriptLock();
  const conseguiuLock = lock.tryLock(10000);

  if (!conseguiuLock) {
    registrarLog_(codigo, '', 'erro', 'Timeout aguardando lock', origem);
    return jsonResponse_({ status: 'erro', mensagem: 'Sistema ocupado, tente novamente.' });
  }

  try {
    // --- Duplicidade: checagem rápida via cache, antes de tocar na planilha
    const cache = CacheService.getScriptCache();
    const cacheKeyDup = 'ultimo_checkin_' + codigo;
    if (cache.get(cacheKeyDup) !== null) {
      const ss = SpreadsheetApp.getActiveSpreadsheet();
      const abs = ss.getSheetByName(SHEET_ABS);
      const linha = localizarLinhaPorCodigo_(abs, codigo);
      const nome = linha !== -1 ? abs.getRange(linha, COL_NOME).getValue() : '';

      registrarLog_(codigo, nome, 'duplicado', 'Nova leitura dentro da janela de ' + JANELA_DUPLICIDADE_SEGUNDOS + 's', origem);
      return jsonResponse_({
        status: 'duplicado',
        nome: nome,
        mensagem: 'Check-in já registrado para ' + (nome || codigo) + '.'
      });
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const abs = ss.getSheetByName(SHEET_ABS);
    const linha = localizarLinhaPorCodigo_(abs, codigo);

    if (linha === -1) {
      registrarLog_(codigo, '', 'nao_encontrado', 'Código BPO não existe na aba ABS', origem);
      return jsonResponse_({
        status: 'nao_encontrado',
        mensagem: 'Código não encontrado. Verifique o QR Code.'
      });
    }

    const nome = abs.getRange(linha, COL_NOME).getValue();
    const turno = abs.getRange(linha, COL_TURNO).getValue();
    const colCheckin = garantirColunaCheckin_(abs);

    const agora = new Date();
    const horaFormatada = Utilities.formatDate(agora, TIMEZONE, "dd/MM HH:mm:ss");

    abs.getRange(linha, colCheckin).setValue(horaFormatada);

    // Marca no cache para bloquear leituras repetidas na janela de tempo.
    cache.put(cacheKeyDup, '1', JANELA_DUPLICIDADE_SEGUNDOS);

    registrarLog_(codigo, nome, 'sucesso', 'Check-in registrado', origem);

    return jsonResponse_({
      status: 'sucesso',
      nome: nome,
      turma: turno, // reaproveita o campo "turma" do frontend para exibir o Turno
      hora: horaFormatada,
      mensagem: 'Presença confirmada para ' + nome + '.'
    });
  } catch (err) {
    registrarLog_(codigo, '', 'erro', 'Exceção: ' + err.message, origem);
    return jsonResponse_({ status: 'erro', mensagem: 'Erro interno ao registrar presença.' });
  } finally {
    lock.releaseLock();
  }
}

/** Busca a linha (1-based) de um "Código BPO" na aba ABS, com cache. */
function localizarLinhaPorCodigo_(abs, codigo) {
  const cache = CacheService.getScriptCache();
  const cacheKey = 'indice_codigo_' + codigo;
  const cacheado = cache.get(cacheKey);

  if (cacheado !== null) {
    const linha = parseInt(cacheado, 10);
    const valorAtual = abs.getRange(linha, COL_CODIGO).getValue();
    if (valorAtual === codigo) return linha;
  }

  const dados = abs.getRange(1, COL_CODIGO, abs.getLastRow(), 1).getValues();
  for (let i = 1; i < dados.length; i++) { // pula cabeçalho
    if (dados[i][0] === codigo) {
      const linhaReal = i + 1;
      cache.put(cacheKey, String(linhaReal), CACHE_INDICE_SEGUNDOS);
      return linhaReal;
    }
  }
  return -1;
}

/** Retorna os últimos N check-ins (com base na coluna Check-in QR), para o dashboard. */
function obterUltimosCheckins_(limite) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const abs = ss.getSheetByName(SHEET_ABS);
  const colCheckin = garantirColunaCheckin_(abs);

  const dados = abs.getRange(1, 1, abs.getLastRow(), colCheckin).getValues();
  const registros = [];

  for (let i = 1; i < dados.length; i++) {
    const horaCheckin = dados[i][colCheckin - 1];
    if (horaCheckin) {
      registros.push({
        codigo: dados[i][COL_CODIGO - 1],
        nome: dados[i][COL_NOME - 1],
        turma: dados[i][COL_TURNO - 1],
        hora: horaCheckin
      });
    }
  }

  // Sem timestamp bruto (a célula guarda texto formatado), então a ordem de
  // "mais recente" segue a ordem de inserção mantida pelo próprio Apps Script
  // não é garantida aqui — para orden ação real por horário, mantenha o
  // formato "dd/MM HH:mm:ss" (ordenável como string dentro do mesmo dia).
  registros.sort((a, b) => (a.hora < b.hora ? 1 : -1));

  return { status: 'ok', total: registros.length, presencas: registros.slice(0, limite) };
}

function validarApiKey_(chaveRecebida) {
  const chaveEsperada = getApiKey_();
  return !!chaveEsperada && chaveRecebida === chaveEsperada;
}

function jsonResponse_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
