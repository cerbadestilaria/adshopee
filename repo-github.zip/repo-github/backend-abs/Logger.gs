/**
 * Logger.gs  (versão adaptada)
 * ---------------------------------------------------------------------------
 * Grava logs numa planilha SEPARADA (nunca na planilha ABS), cujo ID fica
 * salvo em Script Properties (LOG_SPREADSHEET_ID, definido no setup).
 * Best-effort: qualquer falha aqui é engolida para não derrubar o check-in.
 * ---------------------------------------------------------------------------
 */

function registrarLog_(codigo, nome, resultado, detalhes, origem) {
  try {
    const logId = getLogSpreadsheetId_();
    if (!logId) {
      // Sem planilha de logs configurada ainda — cai no log padrão do
      // Apps Script (Ver > Registros de execução), só para não perder o rastro.
      Logger.log(`[${resultado}] ${codigo} — ${detalhes}`);
      return;
    }

    const planilhaLogs = SpreadsheetApp.openById(logId);
    const abaLogs = planilhaLogs.getSheetByName('Logs') || planilhaLogs.getSheets()[0];

    abaLogs.appendRow([
      new Date(),
      codigo || '(vazio)',
      nome || '',
      resultado,
      detalhes || '',
      origem || 'desconhecida'
    ]);
  } catch (err) {
    Logger.log('Falha ao registrar log (ignorada): ' + err.message);
  }
}
