# Sistema de Controle de Presença por QR Code

Sistema de check-in de colaboradores via QR Code / leitor USB, desenvolvido para a operação
Shopee Logística (SOC-SP18). Este README resume o estado atual, as decisões de arquitetura e
o que falta para produção — leia antes de mexer no código.

## TL;DR — qual arquivo usar

**A ferramenta que está em uso real hoje é `ferramenta-offline/teste-offline.html`.**

O restante (`backend-generico/`, `backend-abs/`, `frontend/`) é a **arquitetura original**
(Google Sheets + Apps Script, tempo real) que funciona tecnicamente, mas está **bloqueada em
produção** por uma política do Google Workspace da empresa que impede Apps Script de ser
publicado com acesso público anônimo (`Anyone, even anonymous`). Ver seção "Por que existem
duas arquiteturas" abaixo.

## Estrutura do repositório

```
backend-generico/     Apps Script genérico (Etapa 1) — Google Sheets como banco de dados
backend-abs/          Apps Script adaptado à planilha real de RH (aba "ABS")
frontend/             Frontend original (index.html = leitor, dashboard.html = painel ao vivo)
                       Depende do backend acima estar publicado e acessível
ferramenta-offline/   ⭐ Ferramenta atualmente em uso — 100% client-side, sem backend
docs/                 Documentação das etapas de desenvolvimento (histórico de decisões)
```

## Por que existem duas arquiteturas

### Arquitetura original (backend-generico / backend-abs / frontend)

- Google Sheets como banco de dados, Google Apps Script como API (`doGet`/`doPost`).
- `LockService` para evitar condição de corrida, `CacheService` para performance e janela
  anti-duplicidade (15s).
- Frontend estático (HTML/JS puro) chamando a API via `fetch`.
- **Funciona tecnicamente** — testado, documentado, com testes de concorrência e duplicidade.
- **Bloqueado em produção**: a política do Workspace da empresa não permite que Apps Script
  seja publicado com acesso "Qualquer pessoa, mesmo anônima" — só permite acesso autenticado
  dentro do domínio, o que quebra `fetch()` de fora (erro de CORS/auth, não é bug do código).

### Ferramenta offline (`ferramenta-offline/teste-offline.html`)

Pivô feito para contornar o bloqueio acima, **sem esperar o TI liberar a política**:

- Roda inteiramente no navegador, sem servidor/backend algum.
- Upload de CSV/XLSX (planilha do turno) → dados ficam em memória + `localStorage`.
- Leitor USB (funciona como teclado — nenhuma integração especial necessária) como método
  principal de leitura; câmera foi removida a pedido (não é usada na operação).
- Persistência local automática (sobrevive a crash/fechamento de aba) com opção de restaurar
  sessão anterior.
- Aba de geração de QR Code (cadastro rápido de pessoa não presente na planilha).
- Protótipo de reconhecimento facial (`reconhecimento-facial-prototipo.html`) — **não
  aprovado para uso com funcionários reais**, ver aviso no próprio arquivo (dado biométrico é
  dado sensível pela LGPD, precisa de aprovação jurídica/RH antes de qualquer uso real).
- Cada notebook/estação roda de forma independente — **não há sincronização em tempo real
  entre máquinas diferentes** (ver limitações abaixo). Identificação por "Líder" no nome do
  CSV exportado facilita consolidação manual no fim do turno.

## Limitações conhecidas (não é dívida técnica escondida — é consciente)

1. **Sem sincronização entre notebooks.** Cada estação é isolada. Consolidação de múltiplos
   CSVs exportados é manual. Resolver isso exige um backend acessível de qualquer máquina —
   ou a política do Workspace ser liberada, ou migrar para algo como Firebase/Supabase (ainda
   não avaliado se esses domínios passam pelo firewall da empresa).
2. **Dados de colaborador ficam em `localStorage`** do navegador de cada notebook. Ok para
   piloto; vale checar com o time de dados/privacidade antes de uso continuado, especialmente
   se os notebooks forem compartilhados entre turnos.
3. **Processo de preparar a planilha do turno é manual** (RH/líder exporta do sistema oficial,
   copia pra outra planilha, exporta CSV, sobe na ferramenta). Já causou pelo menos um erro de
   `#REF!` por colar em cima de fórmula existente — vale documentar/automatizar esse passo.
4. **Nunca testado por um operador real sem o desenvolvedor por perto.** Todo teste até agora
   foi feito pelo time de desenvolvimento.
5. **Sem testes automatizados.** Toda validação foi manual (ver `docs/` para o que foi testado
   e quando).

## Se for continuar o desenvolvimento

Duas direções possíveis, dependendo de prioridade:

- **Curto prazo / pragmático**: continuar evoluindo `teste-offline.html` — próximos candidatos
  óbvios são consolidação automática de CSVs de múltiplas estações (ex: um script simples que
  lê vários CSVs e junta) e um passo a passo à prova de erro para preparar a planilha do turno.
- **Médio prazo / arquitetura correta**: retomar `backend-generico`/`backend-abs` +
  `frontend`, condicionado a uma de duas coisas: (a) TI liberar a política de Apps Script
  público, ou (b) migrar o backend para outro provedor (Firebase é o candidato mais óbvio,
  mas precisa validar se não é bloqueado pelo mesmo tipo de política de rede corporativa).

## Stack

- Backend original: Google Apps Script (JavaScript/V8), Google Sheets.
- Ferramenta offline: HTML/CSS/JS puro, sem framework. Bibliotecas via CDN:
  [`xlsx`](https://github.com/SheetJS/sheetjs) (leitura de planilha),
  [`qrcode`](https://github.com/soldair/node-qrcode) (geração de QR),
  [`face-api.js`](https://github.com/justadudewhohacks/face-api.js) (só no protótipo facial).
- Sem build step, sem dependências instaladas — qualquer arquivo `.html` roda abrindo direto
  no navegador.
